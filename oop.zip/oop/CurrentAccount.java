public class CurrentAccount extends Account {
    private final double overdraftLimit;
    private static final double MONTHLY_FEE = 10.0;

    public CurrentAccount(String accountNumber, double balance, double overdraftLimit) {
        super(accountNumber, balance);
        if (overdraftLimit < 0) {
            throw new IllegalArgumentException("Overdraft limit cannot be negative.");
        }
        if (balance < -overdraftLimit) {
            throw new IllegalArgumentException("Initial balance cannot be below the overdraft limit.");
        }
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal rejected: amount must be positive.");
        } else if (balance - amount < -overdraftLimit) {
            System.out.println("Withdrawal of " + amount + " rejected on " + accountNumber
                    + ": exceeds overdraft limit of " + overdraftLimit + ".");
        } else {
            balance -= amount;
            System.out.println("Withdrew " + amount + " from " + accountNumber);
            if (balance < 0) {
                System.out.println("  (" + accountNumber + " is now in overdraft)");
            }
        }
    }

    @Override
    public void endOfMonth() {
        balance -= MONTHLY_FEE;
        System.out.println(accountNumber + ": maintenance fee of " + MONTHLY_FEE + " deducted.");
    }
}
