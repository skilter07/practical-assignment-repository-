import java.util.ArrayList;
import java.util.List;

public class BankDemo {
    public static void main(String[] args) {
        List<Account> accounts = new ArrayList<>();
        accounts.add(new SavingsAccount("SAV-001", 1000, 200));   // minimum balance 200
        accounts.add(new CurrentAccount("CUR-001", 500, 300));    // overdraft limit 300
        accounts.add(new SavingsAccount("SAV-002", 300, 100));
        accounts.add(new CurrentAccount("CUR-002", 100, 200));

        System.out.println("=== Starting balances ===");
        for (Account a : accounts) {
            System.out.println(a.accountNumber + ": " + a.getBalance());
        }

        System.out.println("\n=== Withdrawing 700 from every account ===");
        for (Account a : accounts) {
            a.withdraw(700);
        }

        System.out.println("\n=== Withdrawing 150 from every account ===");
        for (Account a : accounts) {
            a.withdraw(150);
        }

        System.out.println("\n=== End of month ===");
        for (Account a : accounts) {
            a.endOfMonth();
        }

        System.out.println("\n=== Final balances ===");
        for (Account a : accounts) {
            System.out.println(a.accountNumber + ": " + a.getBalance());
        }
    }
}