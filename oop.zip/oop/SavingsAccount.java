public class SavingsAccount extends Account {
    private final double minimumBalance;
    private static final double INTEREST_RATE = 0.02; // 2% per month

    public SavingsAccount(String accountNumber, double balance, double minimumBalance) {
        super(accountNumber, balance);
        if (minimumBalance < 0) {
            throw new IllegalArgumentException("Minimum balance cannot be negative.");
        }
        if (balance < minimumBalance) {
            throw new IllegalArgumentException("Initial balance cannot be below the minimum balance.");
        }
        this.minimumBalance = minimumBalance;
    }

    @Override
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal rejected: amount must be positive.");
        } else if (balance - amount < minimumBalance) {
            System.out.println("Withdrawal of " + amount + " rejected on " + accountNumber
                    + ": balance would fall below the minimum of " + minimumBalance + ".");
        } else {
            balance -= amount;
            System.out.println("Withdrew " + amount + " from " + accountNumber);
        }
    }

    @Override
    public void endOfMonth() {
        double interest = balance * INTEREST_RATE;
        balance += interest;
        System.out.println(accountNumber + ": interest of " + interest + " added.");
    }
}
